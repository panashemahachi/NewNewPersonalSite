<?php

/* 

Still need email checker

*/
$myemail = "panashe_m@live.com";

/* Check all form inputs */
$name = check_input($_POST['InputName']);
$email = check_input($_POST['InputEmail']);
$message = check_input($_POST['InputMessage']);
$headers = 'From: pog@pmahachi.com' . "\r\n" .
    'Reply-To: pog@pmahachi.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

/* Email msg */

$subject = "Personal Website Message";

$message = "$name wants to talk:
Email: $email
Message:
$message

";

/* Send message */
mail($myemail, $subject, $message, $headers);


/* Functions used */
function check_input($data, $problem='')
{
$data = trim($data);
$data = stripslashes($data);
$data = htmlspecialchars($data);
if ($problem && strlen($data) == 0)
{
show_error($problem);
}
return $data;
}

function show_error($myError)
{
?>
<html>
<body>

<p>Please correct the following error:</p>
<strong><?php echo $myError; ?></strong>
<p>Go home, review inputs and try again</p>

</body>
</html>
<?php
exit();
}
?>